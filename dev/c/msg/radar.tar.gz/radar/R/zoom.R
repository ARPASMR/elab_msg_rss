"zoom"<-
function(datamap=map,xstart, ystart, xend, yend,cont=FALSE)
{
image.plot(xstart:xend, ystart:yend,
        datamap[xstart:xend, ystart:yend],asp=1)
if (cont)
 contour(xstart:xend, ystart:yend,
        datamap[xstart:xend, ystart:yend],add=T)
grid()
}
