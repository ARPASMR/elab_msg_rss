"zoomutm"<-
function(datamap,xstart, ystart, xend, yend, cols, cont=FALSE, min, max, step)
{

image.plot(datamap,xlim=c(xstart,xend), ylim=c(ystart,yend),asp=1, col=cols)

if (cont)
 contour(datamap,xlim=c(xstart,xend), ylim=c(ystart,yend),asp=1, levels=seq(min,max,step),add=T)

grid()
}
