"confini"<-function(col, lwd,lty) {

data(confini_piemonte.dat)
xdem <- confini_piemonte.dat$V1
ydem <- confini_piemonte.dat$V2
lines(xdem/1000,ydem/1000,col=col,lwd=lwd,lty=lty)

data(confini_liguria.dat)
xdem <- confini_liguria.dat$V1
ydem <- confini_liguria.dat$V2
lines(xdem/1000,ydem/1000,col=col,lwd=lwd,lty=lty)

data(confini_emilia.dat)
xdem <- confini_emilia.dat$V1
ydem <- confini_emilia.dat$V2
lines(xdem/1000,ydem/1000,col=col,lwd=lwd,lty=lty)

data(confini_toscana.dat)
xdem <- confini_toscana.dat$V1
ydem <- confini_toscana.dat$V2
lines(xdem/1000,ydem/1000,col=col,lwd=lwd,lty=lty)

data(confini_francia.dat)
xdem <- confini_francia.dat$V1
ydem <- confini_francia.dat$V2
lines(xdem/1000,ydem/1000,col=col,lwd=lwd,lty=lty)

data(confini_valdaosta.dat)
xdem <- confini_valdaosta.dat$V1
ydem <- confini_valdaosta.dat$V2
lines(xdem/1000,ydem/1000,col=col,lwd=lwd,lty=lty)

data(confini_svizzera.dat)
xdem <- confini_svizzera.dat$V1
ydem <- confini_svizzera.dat$V2
lines(xdem/1000,ydem/1000,col=col,lwd=lwd,lty=lty)

}

