"r2dutm"<-
function(fname=NULL,nbyte=1,xdim=500,ydim=xdim,
	x0=274234.9,y0=4763898.0,res=0.8,a=0, b=1,null_data=NA,pl=F)
{
rx <- 0
i <- 0

rain <- file(fname,"rb")
map <- readBin(rain,integer(),n=xdim*ydim,size=nbyte,signed=F)
close(rain)

if (!is.na(null_data))
  map[map==null_data]<-NA

map<-a+b*map

map <- matrix(map ,xdim,ydim)

"obs" <-
structure(list(
x = (x0 / 1000. + (0:(xdim - 1)) * res + 0.5 * res),
y = (y0 / 1000. + (0:(ydim - 1)) * res + 0.5 * res),
z = map,
.Names = c("x", "y", "z"),
class = "data.frame"))

if (pl)
  image.plot(obs,asp=1, xlab="UTM X (km)", ylab="UTM Y (km)")

return (obs)

}
