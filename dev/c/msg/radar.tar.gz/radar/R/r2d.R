"r2d"<-
function(fname=NULL,nbyte=1,xdim=500,ydim=xdim,null_data=NA,
	a=0,b=1,pl=T)
{
rx <- 0
i <- 0

rain <- file(fname,"rb")
map <- readBin(rain,integer(),n=xdim*ydim,size=nbyte,signed=F)
close(rain)

if (!is.na(null_data))
  map[map==null_data]<-NA

map<-a+b*map

"obs" <-
structure(list(
x = (1:xdim),
y = (1:ydim),
z = matrix(map,xdim,ydim),
.Names = c("x", "y", "z"),
class = "data.frame"))

if (pl)
	image.plot(obs,asp=1)

return (obs)
}
