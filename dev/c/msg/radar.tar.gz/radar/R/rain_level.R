"rainLevel"<-
function(upper, nlevels=14)
{
	a<-seq(0,log10(upper),log10(upper)/nlevels)
	
	return (round(10^a,1))
}
