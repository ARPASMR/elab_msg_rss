dsd_inten<-function(nomefile, tit="", interv=1, do_mask=F) {

gammap <- function(x,p)
	{
	gamma(x) * pgamma(p,x,1)
	}


  diametri<-c(0.125,0.250,0.375,0.500,0.750,1.0,1.250,1.500,1.750,2.0,2.5,3.0,3.5,4.0,4.5,5.0,5.5,6.0,6.5,7.0)
  deltaDiam<-c(0.125,0.125,0.125,0.25,0.25,0.25,0.25,0.25,0.25,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.25)
  meanDiam<-diametri + deltaDiam / 2.
  vel<-c(0.0001,0.2,0.4,0.6,0.8,1,1.4,1.8,2.2,2.6,3,3.4,4.2,5,5.8,6.6,7.4,8.2,9,10)
  atlas<-9.65-10.3*exp(-0.6*meanDiam)
  data(Atlas.dat)



# AGGIUNTA PER RAPPORTO ASSIALE E CALCOLO ZH, ZDR
De <- meanDiam
#Pruppacher-Beard (1970)
ratio1 <- 1.03 - 0.062 * De
#Beard-Chuang (1987)
ratio2 <- 1.0048 + 5.7*(10^(-4))*De - 2.628*(10^(-2))*(De^2) + 3.682*(10^(-3))*(De^3) -1.677*(10^(-4))*(De^4)
#Andsager
ratio3 <- 1.012 - 0.01445*De - 0.01028*(De^2)
ratio <- ratio3
ratio[De < 1 | De > 4] <- ratio2[De < 1 | De > 4]
ratio[ratio > 0.99999] <- 0.99999

n = 8.7
k = 1.33
ReK = ((n*n-k*k-1)*(n*n-k*k+2)+4*n*n*k*k) / ((n*n-k*k+2)^2 + 4*n*n*k*k)
ImK = 6*n*k/((n*n-k*k+2)^2 + 4*n*n*k*k)
K   = ReK^2 + ImK^2	
e = sqrt( 1 - (ratio^2) )
Av = ( e^(-2))*(1-sqrt(e^(-2)-1) * asin(e) )     
Ah = (1 - Av) / 2
K1 = (n*n - k*k - 1)
K2_v = 1 + Av*K1
K2_h = 1 + Ah*K1
Den_v = K2_v^2 + 4*Av*Av*n*n*k*k     
Den_h = K2_h^2 + 4*Ah*Ah*n*n*k*k
Alpha_v = (K1*K2_v + 4*Av*n*n*k*k) / Den_v
Alpha_h = (K1*K2_h + 4*Ah*n*n*k*k) / Den_h
Beta_v = 2*n*k/Den_v
Beta_h = 2*n*k/Den_h
Sv = Alpha_v*Alpha_v+Beta_v*Beta_v
Sh = Alpha_h*Alpha_h+Beta_h*Beta_h
# FINE AGGIUNTA PER RAPPORTO ASSIALE E CALCOLO ZH, ZDR


# superficie di campionamento 

  Sup<-4560*1E-6
  ro<-1

# leggo i dati dal file ed annullo quelli anomali rispetto ad Atlas 1973

  scanmat <- matrix(scan(nomefile,sep=";"),ncol=400,byrow=T)

# numero di minuti in cui si � ottenuta intensit� pari ad R

  nMin<-nrow(scanmat)

  Rdsd<-1:nMin*NA
  Z<-1:nMin*NA
  Zrad<-1:nMin*NA
  ECflux<-1:nMin*NA
  No<-1:nMin*NA
  lambda<-1:nMin*NA
  mu<-1:nMin*NA
  D0<-1:nMin*NA
  eta<-1:nMin*NA

  ZH<-1:nMin*NA
  ZDR<-1:nMin*NA
  ZHG<-1:nMin*NA
  ZDRG<-1:nMin*NA

  totalND <<- (1:20)*0

  deltaT<-60*interv

  dtdv<- 1 / (vel %o% deltaDiam)

  for ( m in seq(1,nMin,interv)){

   mat<-array(0,c(20,20))

   for ( j in m:(m + interv - 1))
     mat<-mat + aperm(array(scanmat[j,1:400],c(20,20)))

   if (do_mask) {

# elimino la prima classe

      mask[1,1:20]  <-0
      mask[19:20,1:20] <-0

#      mask[1:3,1:20]  <-0
#      mask[17:20,1:20] <-0

      mat<-mat*mask

   }

   if (sum(mat) > 25) {

     cat("m = ", m, "\n")

     ND<-rowSums((mat * aperm(dtdv)) / (Sup * deltaT ))
     NDM<-(mat * aperm(dtdv)) / (Sup * deltaT )
     
     totalND <<- totalND + ND
     
     # Distribuzione gamma x prova
     #ND = 1000 * meanDiam^(2) * exp (-5*meanDiam)
     #ND[15:20] = 0

# Calcolo i parametri della DSD con il metodo dei momenti (Ulbrich et al., 1997)

     p2<-sum(meanDiam^2 * ND * deltaDiam)
     p3<-sum(meanDiam^3 * ND * deltaDiam)
     p4<-sum(meanDiam^4 * ND * deltaDiam)
     p6<-sum(meanDiam^6 * ND * deltaDiam)

     eta[m] = p4^2 / (p2 * p6)

     if ( eta[m] < 0.9) {
	

#-----------------------------------------------------------------------------------------------------
# Distribuzione Gamma troncata
#Dm = p4 / p3	
#Dmax = 0
#index = length(meanDiam)
#while (Dmax == 0)
#	{     	
#	if ( ND[index] > 0 ) Dmax = meanDiam[index]
#	index = index - 1
#	}
#cat("Dmax = ", Dmax, "\n")
#cat("Dm   = ", Dm, "\n")
#vmu  = (10:510)*NA
#vlambda  = (10:510)*NA
#alfa = (10:510)*NA
#
#for (ia in 1:501)
#	{
#	alfa = (ia+9) / 10
#	#cat("ia = ", ia, "alfa = ", alfa, "\n")
#	diff = 1000
#	for (ii in -20:100)
#		{
#		imu = ii / 10
#		tmp = (gammap(5+imu, alfa*Dmax/Dm)^2) / ( gammap(3+imu, alfa*Dmax/Dm)*gammap(7+imu, alfa*Dmax/Dm) )
#		#cat("eta = ", eta[m], "imu = ", imu, "tmp = ", tmp, "\n")
#		
#		if (abs(tmp - eta[m]) < diff)
#			{
#			diff = abs(tmp - eta[m])			 
#			vmu[ia] = imu
#			vlambda[ia] = ( (p2*gammap(5+vmu[ia], alfa*Dmax/Dm)) / (p4*gammap(3+vmu[ia], alfa*Dmax/Dm)) ) ^ 0.5
#			}			
#		}
#	#cat("eta = ", eta[m], "imu = ", imu, "vmu = ", vmu[ia], "\n")
#	}
#
#lambdadiff = vlambda - ((((1:501)+9)/10) / Dm)
#indice = which.min(abs(lambdadiff))
#alfa = (indice+9)/10
##cat("indice = ", indice, "alfa = ", alfa, "mu = ", vmu[indice], "lambda = ", vlambda[indice], "\n")
#
#mu[m] = vmu[indice]
#lambda[m] = vlambda[indice]
#No[m] = p2 * lambda[m]^(2+mu[m]+1) / gammap(2+mu[m]+1, alfa*Dmax/Dm)
#
#cat("INCOMPLETE GAMMA: mu = ", mu[m], "lambda = ", lambda[m], "N0 = ", No[m], "\n")
#
#    plot(De, log(No[m]*(De^mu[m])*exp(-lambda[m]*De)), type="l",col="red")
#    points(De, log(ND), pch=19)
#
#-----------------------------------------------------------------------------------------------------
# Fine distribuzione Gamma troncata


      mu[m]<-((7 - 11*eta[m]) - ((7 - 11*eta[m])^2 - 4*(eta[m] - 1)*(30*eta[m] - 12))^0.5) / (2 * (eta[m] - 1))
      lambda[m]<-(((4 + mu[m]) * (3 + mu[m]) * p2) / p4)^0.5
      D0[m]<-(3.67 + mu[m]) / lambda[m]
      No[m]<-(p2 * lambda[m]^(3 + mu[m])) / gamma(3 + mu[m])


	cat("GAMMA: mu = ", mu[m], "lambda = ", lambda[m], "N0 = ", No[m], "\n")

     plot(De, log(No[m]*(De^mu[m])*exp(-lambda[m]*De)), type="l",col="red")
     points(De, log(ND), pch=19)
     lines(De, log(No[m]*(De^mu[m])*exp(-lambda[m]*De)), type="l",col="black")





# Calcolo la pioggia

#      Rdsd[m]<-(pi * 6.) * ro * sum( (meanDiam^3 * (ND  / dtdv) ) ) 

       Rdsd[m]<-(pi * 600) * ro * sum( (meanDiam^3 * rowSums(mat) / ((Sup * 1E6) * deltaT) ) )

#      cat("Rdsd = ", Rdsd[m], "Prec = ", prec, "\n")

# Calcolo riflettivita' in dbZ

#      if (Rdsd[m] > 0.1) 
             Z[m]<-10*log10(sum(meanDiam^6 * deltaDiam * ND))

# Z teorica da radar per M-P con a=300, b=1.5

       Zrad[m]<-10*log10(300*(Rdsd[m]^1.5))

# Flusso Energia cinetica

       ECflux[m] <- (3 * pi * 1E-4) * (meanDiam^3 * deltaDiam) %*% (NDM %*% aperm(array(vel^3,c(1,20))))

#-------------------------------------------------------------------------------------------------
#	Calcola ZH e ZDR	
	#Nota la sezione d'urto, integra per calcolare Zdr 
	K3 = (De^6) * ND * deltaDiam
	
	#cat("sum(Sh) = ", sum(Sh),"sum(Sv) = ", sum(Sv), "\n")
	
	Iv = sum(K3*Sv)
	Ih = sum(K3*Sh)
	N  = sum(K3)
	
	ZDR[m] = 10*log10(Ih/Iv)
	ZH[m]  = 10*log10(Ih / (9*K))
	
	
	# Stima da distribuzione gamma fittata
	maxd = 17
	K3 = (De[1:maxd]^6) * (No[m]*(De[1:maxd]^mu[m])*exp(-lambda[m]*De[1:maxd])) * deltaDiam[1:maxd]
	Iv = sum(K3*Sv[1:maxd])
	Ih = sum(K3*Sh[1:maxd])
	N  = sum(K3)	
	ZDRG[m] = 10*log10(Ih/Iv)
	ZHG[m]  = 10*log10(Ih / (9*K))
	
	#cat("ZH = ", ZH[m], "ZDR = ", ZDR[m], "\n")

#	Fine Calcolo ZH e ZDR
#-------------------------------------------------------------------------------------------------
   
     
     
     
     
     }

    }

  }

  Z = ZH
  plot(log10(Rdsd),Z, ylab="reflectivity (dBZ)", xlab="Rain (dB)", main=tit)

  abline(10*log10(300), 15., col='red')

  fit<-lm(Z ~ log10(Rdsd))
  coefficienti<-coefficients(fit)

  print(summary(fit))

  cat("A = ", 10^(coefficienti[1]/10.), "B = ", coefficienti[2]/10., "\n")

  abline(fit,col='blue')

  grid()

  plot(ZH, ZDR,xlim=c(5,55),ylim=c(0,3.5))
  grid(col="blue")



  dsd<-data.frame(Rdsd, Z, Zrad, ZH, ZDR, ZHG, ZDRG, ECflux, mu,log10(lambda),log10(No),D0)

  names(dsd)<-c("Rdsd", "Z", "Zrad", "ZH", "ZDR", "ZHG", "ZDRG", "ECflux", "mu", "lambda", "No","D0")

  return(dsd)

}
