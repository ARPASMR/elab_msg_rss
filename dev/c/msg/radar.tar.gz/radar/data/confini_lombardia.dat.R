confini_lombardia.dat<-read.table("confini_lombardia.dat")
