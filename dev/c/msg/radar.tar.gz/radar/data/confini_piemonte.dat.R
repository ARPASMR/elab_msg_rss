confini_piemonte.dat<-read.table("confini_piemonte.dat")
