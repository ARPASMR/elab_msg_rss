confini_toscana.dat<-read.table("confini_toscana.dat")
