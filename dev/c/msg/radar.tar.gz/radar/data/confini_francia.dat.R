confini_francia.dat<-read.table("confini_francia.dat")
