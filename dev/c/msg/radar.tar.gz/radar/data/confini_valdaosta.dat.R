confini_valdaosta.dat<-read.table("confini_valdaosta.dat")
