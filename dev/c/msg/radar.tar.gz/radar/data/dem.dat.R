"dem.dat" <-
structure(list(
x = (274234.9 / 1000. + (1:500) * 0.8),
y = (4763898.0 / 1000. + (1:500) * 0.8),
z = matrix(scan("dem.dat",skip=6),500,500),
.Names = c("x", "y", "z"),
class = "data.frame"))

