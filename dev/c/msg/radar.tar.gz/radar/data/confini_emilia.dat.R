confini_emilia.dat<-read.table("confini_emilia.dat")
