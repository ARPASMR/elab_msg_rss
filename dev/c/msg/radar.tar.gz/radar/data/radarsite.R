"radarsite" <-
structure(list(
NRO = c(1, 2),
NAME = c("BRIC DELLA CROCE", "MONTE SETTEPANI"),
UTMX = c(400276, 436045),
UTMY = c(4987711, 4899709),
ELEV = c(773, 1385),
RANGE = c(125, 136),
OWNER = c("Arpa Piemonte", "Arpa Piemonte")),
.Names = c("NRO", "NAME", "UTMX", "UTMY", "ELEV","RANGE","OWNER"),
class = "data.frame", row.names = c("1", "2"))
