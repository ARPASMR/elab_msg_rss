confini_svizzera.dat<-read.table("confini_svizzera.dat")
