confini_liguria.dat<-read.table("confini_liguria.dat")
